
package RegistrationLogin;

import java.util.Scanner;
import javax.swing.JOptionPane;


class UserInfo {
    // declaring my variables
    private static int NumberOfTask;
    private static String Status;
    private static String DeveloperDetails;
    public static int TaskNumber;
    private static String TaskName;
   private static String Discription;
    private static int Duration;
    private static int TaskID;
    
    static int duration = 0;
  
    // getting inputs from the user
    Scanner input = new Scanner(System.in);
    public static void setNumberOfTask(){
        NumberOfTask = Integer.parseInt(JOptionPane.showInputDialog("Enter number of task you wish to perform"));
    }
    public static int getNumberOfTask(){
        return NumberOfTask;
    }
    public static void setTaskName(){
        
        TaskName = JOptionPane.showInputDialog("Enter Task Name");
        
    }
    public static String getTaskName(){
        return TaskName;
    }
    
    public static void setTaskNumber(int x){
          TaskNumber = x;
    }
    public static int getTaskNumber(){
        return TaskNumber;
    }
    
    public static void setDiscription(){
        
        Discription = JOptionPane.showInputDialog("Enter Task Discription");
        
    }
    public static String getDiscription(){
        return Discription;
    }
    
    public static void setDuration(){
        
        Duration = Integer.parseInt(JOptionPane.showInputDialog("Enter Task Duration"));
        
    }
    public static int getDuration(){
        return Duration;
    }
    
     public static void setStatus(){
         //creating option and organising the task that needs to be done
        
        Status = JOptionPane.showInputDialog("Choose task status \n"
                + "To Do\n"
                + "Doing\n"
                + "Done");
        
    }
    public static String getStatus(){
        return Status;
    }
    public static void setDeveloperNames(){
        
        DeveloperDetails = JOptionPane.showInputDialog("Enter DeveloperNames");
        
    }
    public static String getDeveloperNames(){
        return DeveloperDetails;
    }
    
    // this will work only if the user is succesfully logged in
    public static void WelcomeNote(){
    int option;
    int end = 0;
      Login log = new Login();
      Task obj = new Task();
      
      if(log.loginUser()){
          
          do{
              
               option = Integer.parseInt(JOptionPane.showInputDialog("Welcome to EasyKanban\n"
                  + "Please select an option \n"
                  + "1. Add task \n"
                  + "2. Show report \n"
                  + "3. Quit "));
         
              
            if(option == 1){
                
                setNumberOfTask();
                
                for(int count= 0; count<getNumberOfTask(); count++){
                    //TaskNumber = count;
                    setStatus();
                    setTaskNumber(count);
                    setTaskName();
                    setDiscription();
                    setDuration();
                    setDeveloperNames();
                    
                    duration = duration+ getDuration();
                    JOptionPane.showMessageDialog(null, obj.printTaskDetails());
                }
                JOptionPane.showMessageDialog(null, "These tasks will take " + duration + " to implement");
                
                continue;
            }
            else if(option == 2){
            JOptionPane.showMessageDialog(null,"Coming soon");
            continue;
            }
            else if(option == 3){

               end= 3; 
            }
          
      }while(end != 3);
    }
    }
    }
    
